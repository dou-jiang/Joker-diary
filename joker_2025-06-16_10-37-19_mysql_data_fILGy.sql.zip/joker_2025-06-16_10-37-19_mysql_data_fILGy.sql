-- MySQL dump 10.13  Distrib 5.7.44, for Linux (x86_64)
--
-- Host: localhost    Database: joker
-- ------------------------------------------------------
-- Server version	5.7.44-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admins`
--

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` VALUES (1,'admin','123456','2025-06-11 09:00:14');
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `celebrations`
--

DROP TABLE IF EXISTS `celebrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `celebrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `diary_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `qq` varchar(20) NOT NULL,
  `avatar_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `diary_id` (`diary_id`),
  CONSTRAINT `celebrations_ibfk_1` FOREIGN KEY (`diary_id`) REFERENCES `diaries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `celebrations`
--

LOCK TABLES `celebrations` WRITE;
/*!40000 ALTER TABLE `celebrations` DISABLE KEYS */;
INSERT INTO `celebrations` VALUES (11,33,'瑞','527191253','https://q1.qlogo.cn/g?b=qq&nk=527191253&s=640','2025-06-11 18:43:52'),(12,34,'瑞','527191253','https://q1.qlogo.cn/g?b=qq&nk=527191253&s=640','2025-06-11 19:11:26'),(13,35,'闻宴','2632812017','https://q1.qlogo.cn/g?b=qq&nk=2632812017&s=640','2025-06-12 05:11:06'),(14,35,'瑞','527191253','https://q1.qlogo.cn/g?b=qq&nk=527191253&s=640','2025-06-12 05:25:58');
/*!40000 ALTER TABLE `celebrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `diaries`
--

DROP TABLE IF EXISTS `diaries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `diaries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `category` varchar(50) NOT NULL,
  `image_path` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `published_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `publish_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diaries`
--

LOCK TABLES `diaries` WRITE;
/*!40000 ALTER TABLE `diaries` DISABLE KEYS */;
INSERT INTO `diaries` VALUES (31,'测试一下','测试一下','日常','[\"http:\\/\\/joker.cysq8.cn\\/uploads\\/1.png\",\"http:\\/\\/joker.cysq8.cn\\/uploads\\/1f81098a32102f32024e9e78c803068.jpg\",\"http:\\/\\/joker.cysq8.cn\\/uploads\\/1.png\",\"http:\\/\\/joker.cysq8.cn\\/uploads\\/1f81098a32102f32024e9e78c803068.jpg\"]','2025-06-11 16:56:17','2025-06-11 19:10:48','2025-06-12 00:56:17','1999-06-12 00:55:00'),(33,'6.10日','初见端倪\r\n图片顺序很乱','日常','[\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/BOHa\\/IMG_1149.png\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/KWUb\\/2c9340a562302a53379e27216094f4d7.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/n3T9\\/855278314534254d904d8daef99b9724.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/ZwSv\\/e44c1d08738b406ef884f11380543fec.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/PPC2\\/1b35d6c950ffc291f747ae9270d77fe5.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/LqcV\\/47a2bda92048ed640ac198f71042522b.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/V3t3\\/IMG_1207.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/zqsz\\/6c7cbbb4e6ad64ea353818a188a16952.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/omuD\\/303b242c709e202ea87558fd7d9dd832.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/rQIW\\/b99d9a49d1fc44e9c8f0b7577d38301e.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/Ewf5\\/d71abea11a66a29d75746238acb25653.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/GEFD\\/IMG_1211.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/7oh2\\/dcb7e5dfe872408ee37a5e408401c4cc.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/OJi2\\/823a25fa65189c17893d01dd6869d8b8.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/wa2HL\\/IMG_1216.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/YkkUa\\/IMG_1215.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/21rTM\\/IMG_1217.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/g93S2\\/fb29ed8f882509b122847cf56af0884b.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/WOJCn\\/cca34bb9342e30a3c122dc8a7b77b3a2.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/yKWcJ\\/7b5a4c859e297373ed61c90ba75f07f7.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/ke2tO\\/c4c5f41c648ff467345d8e0d13c31fc8.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/5ZqsO\\/653e6759239c18f196ade2fe30a4e04c.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/9Bnun\\/c6a26a93948d79381da2ef41ce3f09ab.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/4PQI7\\/466efb34ce1832562e78e799301699c6.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/pn5fv\\/b17003387402ef606a217c694092a4ee.jpeg\"]','2025-06-11 18:29:58','2025-06-11 19:00:15','2025-06-12 02:29:58','2025-06-10 21:00:00'),(34,'6.11','坠入爱河\r\n图片顺序很乱','日常','[\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/qEMFO\\/fac96b23d63452651cb52f2a59a9d9d5.png\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/vbEh7\\/5ddc3f4e2342e96d0eecd140ac8d1dab.png\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/mbKir\\/48072d889f8747268ddb8e59b7fab1ae.png\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/6BEHm\\/d0ae024555ee0d189950b11d5990ff4c.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/DdJUD\\/cc72b94439bca83fd07ba038be67c152.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/3EgTG\\/f32df278de23f53453f35fdc8fc92339.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/1ZpSd\\/5c5e5c4b15961875a70e81b1a7f84b64.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/A6lta\\/058dbf0934fa517eb2dcb757a00cf44e.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/xpZc4\\/1e422e907c37b2adfd361c881240b2ca.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/dPqtX\\/2f6466c345e78442bf79c3105303915a.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/RowsY\\/6c027276af52a4b75a8cd2d88f6e7531.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/XwLuV\\/IMG_1237.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/JqdIr\\/5493077da7dc0191a747b41c8e704ec3.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/le3f9\\/252ab955ea782c015ac41503d12acf4f.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/e29SL\\/04f15a25d198f951e9caacc37f8bbb69.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/MZGhq\\/266ef905fc2c296fbc636f37599a261f.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/a2kcg\\/532d0c2c9a453509eb9dcf0b1822c896.jpeg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/QyGHp\\/IMG_1243.png\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/bOBUe\\/IMG_1244.png\"]','2025-06-11 19:09:36','2025-06-11 19:09:36','2025-06-12 03:09:36','2025-06-11 21:00:00'),(35,'6.12（睿睿篇）','今天是渣男\r\n图片顺序很乱','日常','[\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/ObJU2\\/IMG_1250.png\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/KEWCb\\/IMG_1251.png\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/7xoH2\\/IMG_1252.png\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/nG3S9\\/Screenshot_2025-06-12-12-53-32-570_com.tencent.mm.jpg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/Z4wIv\\/Screenshot_2025-06-12-12-53-29-521_com.tencent.mm.jpg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/PGPc2\\/Screenshot_2025-06-12-12-53-26-580_com.tencent.mm.jpg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/LeqsV\\/Screenshot_2025-06-12-12-53-22-690_com.tencent.mm.jpg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/V43h3\\/Screenshot_2025-06-12-12-53-18-700_com.tencent.mm.jpg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/z6qFz\\/Screenshot_2025-06-12-12-53-07-806_com.tencent.mm.jpg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/oEmFD\\/Screenshot_2025-06-12-12-53-04-775_com.tencent.mm.jpg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/rmQFW\\/Screenshot_2025-06-12-12-53-12-711_com.tencent.mm.jpg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/Eqwh5\\/Screenshot_2025-06-12-12-32-13-482_com.tencent.mm.jpg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/GmEiD\\/Screenshot_2025-06-12-12-53-01-063_com.tencent.mm.jpg\",\"https:\\/\\/pan.xiaoqiyuan.cn\\/f\\/wK2FL\\/Screenshot_2025-06-12-13-06-38-072_com.tencent.mm-edit.jpg\"]','2025-06-12 05:03:44','2025-06-12 05:07:30','2025-06-12 13:03:44','2025-06-12 12:59:00');
/*!40000 ALTER TABLE `diaries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `diary_images`
--

DROP TABLE IF EXISTS `diary_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `diary_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `diary_id` int(11) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `diary_id` (`diary_id`),
  CONSTRAINT `diary_images_ibfk_1` FOREIGN KEY (`diary_id`) REFERENCES `diaries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diary_images`
--

LOCK TABLES `diary_images` WRITE;
/*!40000 ALTER TABLE `diary_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `diary_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'joker'
--

--
-- Dumping routines for database 'joker'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-16 10:37:19
